FILLED EV MARKET INTELLIGENCE PROJECT TEMPLATES
Student: Anshuman Joshi
Project: Global Electric Vehicle Market Intelligence Dashboard

The original eight template ZIPs were extracted and the editable Word templates were filled with project-specific content where applicable. The final report and demonstration PDFs were populated with the provided scenario and project requirements.

Primary project path: Tableau dashboard. Snowflake-specific templates were also retained and adapted as optional/alternative technical documents because they were included in the supplied template pack.

Important integrity notes:
- No dataset file was provided, so no numerical findings, measured performance, record counts, screenshots, executed query outputs, or published Tableau URL are fabricated.
- Sections requiring actual implementation evidence are marked as pending or instruct you to add verified evidence.
- Update the date, team/project ID if your institution has a required identifier, dataset citation, and actual course deadlines as necessary.
- Student name used: Anshuman Joshi
